class Printer[T] {
    def print(item: T) = {
        println(item.toString())
        this
    }
}

new Printer[AnyVal]().print(1).print(2.3)
