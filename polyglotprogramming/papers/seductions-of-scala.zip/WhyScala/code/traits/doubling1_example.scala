class MyQueue extends StandardQueue with Doubling 
val queue = new MyQueue 
queue.put(10) 
println(queue.get())  // => 20 
