trait IntQueue {   // could also declare as "abstract class"
	def get(): Int 
	def put(x: Int) 
}  
