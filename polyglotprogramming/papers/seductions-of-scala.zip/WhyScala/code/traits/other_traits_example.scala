
val queue = new StandardQueue with Incrementing with Filtering
queue.put(-1); queue.put(0); queue.put(1) 
println(queue.get())  // => 1
println(queue.get())  // => 2
