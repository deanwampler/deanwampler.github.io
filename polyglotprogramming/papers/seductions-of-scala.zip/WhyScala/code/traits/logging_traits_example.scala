//START:queue_def
trait Queue[T] {
	def get(): T 
	def put(t: T) 
}  
//END:queue_def

//START:queue_logging_def
// Add logging for the put method.
trait QueueLogging[T] extends Queue[T] { 
	abstract override def put(t: T) = {
	    println("put("+t+")")
	    super.put(t)    // What is super bound to?
    }
} 
//END:queue_logging_def

//START:queue_example
import scala.collection.mutable.ArrayBuffer 

class StandardQueue[T] extends Queue[T] {
    private val buff: ArrayBuffer[T] = new ArrayBuffer[T]
    def put(t: T) = buff += t
    def get() = buff.remove(0)
    override def toString() = "StandardQueue: "+buff.toString()
}

val queue = new StandardQueue[Int] with QueueLogging[Int]

queue.put(10)        // #1
println(queue.get()) // #2
// => put(10)       (on #1)
// => 10            (on #2)
//END:queue_example
