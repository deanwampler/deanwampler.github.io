// Repeat QueueLogging and StandardQueue definition so you can 
// just run this file as a script.
//START:queue_def
trait Queue[T] {   // could also declare as "abstract class"
	def get(): T 
	def put(t: T) 
}  
trait QueueLogging[T] extends Queue[T] { 
	abstract override def put(t: T) = {
	    println("put("+t+")")
	    super.put(t) 
    }
} 
import scala.collection.mutable.ArrayBuffer 
class StandardQueue[T] extends Queue[T] {
    private val buff: ArrayBuffer[T] = new ArrayBuffer[T]
    def put(t: T) = buff += t
    def get() = buff.remove(0)
    override def toString() = "StandardQueue: "+buff.toString()
}
//END:queue_def

//START:queue_filtering_def
// Add entry filtering.
trait QueueEntryFiltering[T] extends Queue[T] { 
    abstract override def put(t: T) = {
        if (veto(t))
            println("put("+t+") rejected!!")
        else
            super.put(t) 
    }
    def veto(t: T): Boolean
} 
//END:queue_filtering_def

//START:queue_filtering_example1
val queue1 = new StandardQueue[Int] 
    with QueueLogging[Int] with QueueEntryFiltering[Int] {
        def veto(i: Int) = i < 0
    }
    
for (i <- -2 to 2) {
    queue1.put(i)
}
println(queue1)
// => put(-2) rejected!!
// => put(-1) rejected!!
// => put(0)
// => put(1)
// => put(2)
// => StandardQueue: ArrayBuffer(0, 1, 2)
//END:queue_filtering_example1
println("")
//START:queue_filtering_example2
val queue2 = new StandardQueue[Int] 
    with QueueEntryFiltering[Int] with QueueLogging[Int] {
        def veto(i: Int) = i < 0
    }
    
for (i <- -2 to 2) {
    queue2.put(i)
}
println(queue2)
// => put(-2)
// => put(-2) rejected!!
// => put(-1)
// => put(-1) rejected!!
// => put(0)
// => put(1)
// => put(2)
// => StandardQueue: ArrayBuffer(0, 1, 2)
//END:queue_filtering_example2
