val queue = new StandardQueue with Doubling 
queue.put(10) 
println(queue.get())  // => 20 
