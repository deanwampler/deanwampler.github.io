def countScalas(list: List[String]): Int = {
	list match {
		case "Scala" :: tail => countScalas(tail) + 1
		case head :: tail    => countScalas(tail)
		case Nil             => 0
	}
}
val langs = List("Scala", "Java", "C++", "Scala", "Ruby")
val count = countScalas(langs)
println(count)    // => 2
