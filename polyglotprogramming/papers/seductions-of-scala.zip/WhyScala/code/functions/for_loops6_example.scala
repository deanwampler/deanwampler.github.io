object RequireWordsStartingWithPrefix6 {
	def main(args: Array[String]) = {
	    val matched = process(args)
	    matched.foreach((x: (Int, String)) => println("args("+x._1+"): "+x._2))
    }

    def process(args: Array[String]) = {
		val prefix = args(0)
		for {
			i <- 1 to (args.length - 1)
			arg = args(i)
			if arg.startsWith(prefix)
		} yield (i, arg)
	}
}
// $ scala RequireWordsStartingWithPrefix6 xx xy1 xx1 yy1 xx2 xy2
// args(2): xx1
// args(4): xx2
