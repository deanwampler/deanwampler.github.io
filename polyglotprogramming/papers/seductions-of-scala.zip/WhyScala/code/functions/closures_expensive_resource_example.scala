class ExpensiveResourceFailure(th:Throwable) extends RuntimeException(th)

//START:definition
class ExpensiveResource {
	def open(worker: () => Unit) = {
		try {
			println("Doing initialization")
			worker()
		} catch {
		    case th: Throwable => 
		        throw new ExpensiveResourceFailure(th)
		} finally {
			close()
		}
	}
	def close() = {
		println("Doing cleanup")
	}
}
//END:definition
//START:examples
// Example use:
try {
	(new ExpensiveResource()) open { () =>        // 1
		println("Using Resource")                 // 2
		throw new Exception("Thrown exception")   // 3
	}                                             // 4
} catch {
	case e: ExpensiveResourceFailure => println("Caught: "+e)
}
// => Doing initialization
// => Using Resource
// => Doing cleanup
// => Exception caught: ...

//END:examples
