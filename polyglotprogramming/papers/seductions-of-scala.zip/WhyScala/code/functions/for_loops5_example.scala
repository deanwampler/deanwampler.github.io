object RequireWordsStartingWithPrefix5 {
	def main(args: Array[String]) = {
	    filter(args).foreach((arg: String) => println("arg: "+arg))
    }
    def filter(args: Array[String]): List[String] = {
		val prefix = args(0)
		for {
			i <- 1 to (args.length - 1)
			if args(i).startsWith(prefix)
		} yield args(i)
	}
}
// $ scala RequireWordsStartingWithPrefix5 xx xy1 xx1 yy1 xx2 xy2
// arg: xx1
// arg: xx2
