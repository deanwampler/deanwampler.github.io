//START:declarations
//END:declarations
//START:examples
import shapes._
def visit(shape: Shape) = {  // Visitor pattern (of sorts).
    shape match {
        case Circle(center, radius) => 
            "Circle: center, radius = "+center+", "+radius
        case Rectangle(lowerLeft, height, width) => 
            "Rectangle: lower left, height, width = "+lowerLeft+", "+height+", "+width
    }
}
println(visit(Circle(Point(0.0,0.0),1.0)))
println(visit(Rectangle(Point(0.0,0.0),2.0,5.0)))
// => Circle: center, radius = Point(0.0,0.0), 1.0
// => Rectangle: lower left, height, width = Point(0.0,0.0), 2.0, 5.0
//END:examples
