val list = List("Scala", "Haskell", "Java")

println(list.isEmpty)   // => false
println(list.head)      // => "Scala"
println(list.tail)      // => List("Haskell", "Java")
println(list.last)      // => "Java"
