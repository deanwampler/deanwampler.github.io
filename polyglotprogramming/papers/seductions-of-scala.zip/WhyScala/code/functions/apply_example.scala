class Greeter {
	def apply() = "hello"
	def apply(name: String) = "hello "+name
}

val hello = new Greeter
println(hello())        // => "hello"
println(hello("Dean"))  // => "hello Dean"
