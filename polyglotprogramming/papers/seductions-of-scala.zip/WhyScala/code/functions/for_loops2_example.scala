object RequireWordsStartingWithPrefix2 {
	def main(args: Array[String]) = {
		val prefix = args(0)
		for (
			i <- 1 to (args.length - 1); 
			if args(i).startsWith(prefix)
		) println("args("+i+"): "+args(i))
	}
}
// $ scala RequireWordsStartingWithPrefix2 xx xy1 xx1 yy1 xx2 xy2
// args(2): xx1
// args(4): xx2
