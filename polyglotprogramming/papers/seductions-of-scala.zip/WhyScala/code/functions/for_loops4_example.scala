object RequireWordsStartingWithPrefix4 {
	def main(args: Array[String]) = {
		val prefix = args(0)
		for {
			i <- 1 to (args.length - 1)   // no semicolons
			arg = args(i)
			if arg.startsWith(prefix)
		} println("args("+i+"): "+arg)
	}
}
// $ scala RequireWordsStartingWithPrefix4 xx xy1 xx1 yy1 xx2 xy2
// args(2): xx1
// args(4): xx2
