public void exceptionExample() {
	try {
		System.err.println("Before exception:");
		throw new Exception("thrown exception")
	} catch (Exception ex){
		System.err.println(ex)
	}
}
