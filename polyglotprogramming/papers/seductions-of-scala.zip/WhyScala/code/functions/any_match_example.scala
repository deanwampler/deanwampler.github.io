def show3(item: Any) = {  // show3 returns Any
	item match {
		case 5       => "Five"
		case "Five"  => 5
		case true    => false
		case _       => "No hotness found"
  	}
}
println(show3(5))          // => "Five"
println(show3("Five"))     // => 5
println(show3(true))       // => false
println(show3("C++"))      // => "No hotness found"
