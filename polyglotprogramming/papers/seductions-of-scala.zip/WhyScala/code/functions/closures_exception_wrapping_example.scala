def tryWithExceptionHandling(action: => Unit) = {
	try {
		action
	} catch {
		case ex: Exception => println(ex)
	}
}
tryWithExceptionHandling {
	println("Before exception:")
	throw new Exception("thrown exception")
} 
// => Before exception:
// => java.lang.Exception: thrown exception
