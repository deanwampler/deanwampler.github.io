import shapes._
val shapeMap = Map(
	"circle" -> Circle(Point(0.0,0.0), 1.0),
	"rect"   -> Rectangle(Point(0.0,0.0), 2, 5), 
	"exit"   -> "exiting!")
println(shapeMap.get("circle"))      // => Some(Circle(Point...
println(shapeMap.get("rect").get())  // => Rectangle(Point(...
println(shapeMap.get("exit"))        // => Some(exiting!)
println(shapeMap.get("triangle"))    // => None
    