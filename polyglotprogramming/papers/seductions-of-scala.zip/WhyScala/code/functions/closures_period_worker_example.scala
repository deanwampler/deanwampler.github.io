object PeriodicWorker {
	def doEachPeriod(periodInMillis: Int, maxIterations: Int,
					 worker: (Int) => Unit) = {
		var count = 1
		while (count <= maxIterations) {
			worker(count)
			count += 1
			Thread.sleep(periodInMillis)
		}
	}
	def main(args: Array[String]) {
		doEachPeriod(1000, 5, (count: Int) => 
			println("Iteration# "+count))
	}
}
