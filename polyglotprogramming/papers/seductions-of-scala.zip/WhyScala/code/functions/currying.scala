def modulo(mod: Int)(n: Int) = n % mod

def mod3 = modulo(3) _

for (i <- 0 to 3) {
    println(modulo(3)(i)+" == "+mod3(i))
}
// => 0 == 0
// => 1 == 1
// => 2 == 2
// => 0 == 0

