//START:declarations
import shapes._
val shapeMap = Map(
    "circle" -> Circle(Point(0.0,0.0), 1.0),
    "rect"   -> Rectangle(Point(0.0,0.0), 2, 5), 
    "exit"   -> "exit")
//END:declarations
//START:examples
def drawByKey(key: String) = {
    val value: Option[Any] = shapeMap.get(key)
    value match {
        case None => println("Error, no match for "+key+"!")
        case Some(x) => x match {
            case s:Shape => s.draw() 
            case "exit"  => println("Now exiting...")
            case _       => println("Other: "+x)
        }
    }
}
drawByKey("circle")   // => Shape: Circle(Point(0.0,0.0),1.0)
drawByKey("rect")     // => Shape: Rectangle(Point(0.0,0.0),2.0,5.0)
drawByKey("triangle") // => Error, no match for triangle!
drawByKey("exit")     // => Now exiting...
//END:examples
