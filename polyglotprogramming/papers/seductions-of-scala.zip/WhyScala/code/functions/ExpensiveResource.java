public class ExpensiveResource {  // Java idiom...
	public static interface Worker { 
		void doWork();
	}
	public void open(Worker worker) {
		try {
			System.err.println("Doing initialization");
			worker.doWork();
		} catch (Throwable th) {
			reportError(th);
			throw new ExpensiveResourceFailure(th);			
		} finally {
			close();
		}
	}
	protected void close() {
		System.err.println("Doing cleanup");
	}
}
