val hotLangs = Map(
	"Scala" -> "Rocks", 
	"Haskell" -> "Ethereal", 
	"Java" -> null)
println(hotLangs.get("Scala"))          // => Some(Rocks)
println(hotLangs.get("Haskell").get())  // => Ethereal
println(hotLangs.get("Java"))           // => Some(null)
println(hotLangs.get("C++"))            // => None
