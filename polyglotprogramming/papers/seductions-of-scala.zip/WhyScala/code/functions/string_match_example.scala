def show2(language: String) = {
	language match {
		case "Scala"   => "Rocks"
		case "Haskell" => "Ethereal"
		case "Java"    => null
		case _         => "No hotness found"
  	}
}
println(show2("Scala"))    // => "Rocks"
println(show2("Haskell"))  // => "Ethereal"
println(show2("Java"))     // => "null"
println(show2("C++"))      // => "No hotness found"
