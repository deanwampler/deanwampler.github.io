val hotLangs = Map(
	"Scala" -> "Rocks", 
	"Haskell" -> "Ethereal", 
	"Java" -> null)
def show(key: String) = {
	val value: Option[String] = hotLangs.get(key)
  	value match {
    	case Some(x) => x
    	case None => "No hotness found"
  	}
}
println(show("Scala"))  // => "Rocks"
println(show("Java"))   // => "null"
println(show("C++"))    // => "No hotness found"
