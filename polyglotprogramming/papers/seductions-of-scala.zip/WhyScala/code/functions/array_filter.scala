object RequireWordsStartingWithPrefix {
	def main(args: Array[String]) = {
		val prefix = args(0)  // 1st arg is the prefix
		args.slice(1, args.length)  // rest of args...
        .filter((arg: String) => arg.startsWith(prefix))
        .foreach((arg: String) => println("arg: "+arg))
	}
}
// $ scala RequireWordsStartingWithPrefix xx xy1 xx1 yy1 xx2 xy2
// arg: xx1
// arg: xx2
