import shapes._

ShapeDrawingActor.start() 
ShapeDrawingActor ! Circle(Point(0.0,0.0), 1.0)     
ShapeDrawingActor ! Rectangle(Point(0.0,0.0), 2, 5) 
ShapeDrawingActor ! 3.14159  
ShapeDrawingActor ! "exit"   

// => Circle(Point(0.0,0.0),1.0)
// => Rectangle(Point(0.0,0.0),2.0,5.0)
// => Error: 3.14159
// => exiting...
