//START:definition1
import scala.actors._
import scala.actors.Actor._
import java.net.{InetAddress, UnknownHostException}

case class LookupIP(hostName: String, respondto: Actor) 
case class Result(hostName: String, 
                  address: Option[InetAddress])

object HostNameResolver extends Actor {
	def act() {
		loop {
			receive {
				case LookupIP(hostName, actor) => 
					actor ! Result(hostName, getip(hostName))
				case "EXIT" => exit()
			}
		}
	}
	// ...
//END:definition1
//START:definition2
	// ...
	def getip(hostName: String): Option[InetAddress] = {
		try {
			Some(InetAddress.getByName(hostName))
		} catch {
			case _:UnknownHostException => None
		}
	}
}
//END:definition2
//START:examples
HostNameResolver.start()
HostNameResolver ! LookupIP("www.scala-lang.org", self)
HostNameResolver ! LookupIP("wwwww.scala-lang.org", self)
HostNameResolver ! LookupIP("www.objectmentor.com", self)
HostNameResolver ! "EXIT"

for (i <- 1 to 3) self.receive { 
	case Result(hostName, address) => 
		val addr = if (address.isEmpty) 
			"No IP address found" 
		else
			// Hack: InetAddress.getLocalHost() never called, but...
			address.getOrElse(InetAddress.getLocalHost()).getHostAddress()
		println(hostName+": "+addr) 
}
// => www.scala-lang.org: 128.178.154.102
// => wwwww.scala-lang.org: No IP address found
// => www.objectmentor.com: 206.191.6.12
//END:examples