class Person(fn:String, ln:String, a:Int) {
	@scala.reflect.BeanProperty
	var firstName = fn
	
	@scala.reflect.BeanProperty
	var lastName = ln
	
	@scala.reflect.BeanProperty
	var age = a
}
