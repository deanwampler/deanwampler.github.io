class MyNumbers {
    // contrived example:
    import java.util.concurrent.{FutureTask => _, _}
    import java.math.BigInteger.{TEN, ZERO => JZERO }
    
    def write = {
        // FutureTask is effectively undefined
        // val x = new FutureTask[String](new Callable[String]() {...})
        println("TEN: "+TEN)
        println("ZERO: "+JZERO)
    }
}
