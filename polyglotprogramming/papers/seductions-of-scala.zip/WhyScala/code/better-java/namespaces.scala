package rockets.navigation   // Java-like package declaration 
class Navigator { ... } 

package rockets.navigation { // Namespace-like declaration 
	class Navigator { ... } 
} 

package rockets {            // Nested namespace-like declaration 
	package navigation { 
		class Navigator { ... } 
	} 
} 
