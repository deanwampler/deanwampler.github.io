class Complex(val real: Double, val imaginary: Double)
{
	def this(real: Double) = this(real, 0.0)
	// ...
	override def toString() = "("+real+", "+imaginary+")"
}

val c1 = new Complex(1.1, 2.2)
val c2 = new Complex(1.1)
println("c1 = " + c1)                      // => (1.1, 2.2)
println("c2 = " + c2)                      // => (1.1, 0.0)
println("c1.real = " + c1.real)            // => 1.1
println("c1.imaginary = " + c1.imaginary)  // => 2.2
