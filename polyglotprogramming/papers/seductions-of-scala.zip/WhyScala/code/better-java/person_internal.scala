//START:definition1
// Omitting lastName, etc.
class Person(firstName:String) {
	private[this] var fn = ""
	
	def firstName_=(fn2:String): Unit = { fn = fn2 }
	
	def firstName: String = { fn }
}
//END:definition1
//START:definition2
// Omitting lastName, etc.
class Person2(firstName:String) {
	private[this] var fn = ""
	
	def firstName_=(fn2:String) = fn = fn2
	
	def firstName = fn
}
//END:definition2
