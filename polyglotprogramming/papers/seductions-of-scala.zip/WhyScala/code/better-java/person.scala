class Person(var firstName: String, var lastName: String, var age: Int)
