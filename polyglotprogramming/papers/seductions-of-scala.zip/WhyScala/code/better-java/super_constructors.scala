class FancyComplex(real: Double, imaginary: Double) 
	extends Complex(real, imaginary) {
	...
}