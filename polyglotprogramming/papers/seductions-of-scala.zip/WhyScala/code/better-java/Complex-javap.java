// Compiled from "Complex.scala" using "javap -private Complex"
public class Complex extends java.lang.Object implements scala.ScalaObject{
    private final double imaginary;   // final -> read-only
    private final double real;
    public Complex(double, double);
    public java.lang.String toString();
    public Complex unary_$minus();    // a.k.a. "unary_-"
    public Complex $minus(Complex);   // a.k.a. "-"
    public Complex $plus(Complex);    // a.k.a. "+"
    public double imaginary();
    public double real();
    public int $tag();   // scala internals...
}
