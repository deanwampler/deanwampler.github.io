// Same as "Complex.java" but added boilerplate to make it compilable with "java".

public class Complex extends java.lang.Object { //implements scala.ScalaObject{
    private final double imaginary;
    private final double real;
    public Complex(double r, double i) { real = r; imaginary = i; }
    public java.lang.String toString() { return "("+real+","+imaginary+")"; }
    public Complex unary_$minus() { return new Complex(-real, imaginary); }
    public Complex $minus(Complex c) { return new Complex(real-c.real(),imaginary-c.imaginary()); }
    public Complex $plus(Complex c)  { return new Complex(real+c.real(),imaginary+c.imaginary()); }
    public double imaginary() { return imaginary; }
    public double real() { return real; }
    public int $tag() { return 0; }
    
    public static void main(String[] args) {
        Complex c1 = new Complex(1.,2.);
        Complex c2 = new Complex(2.,1.);
        System.out.println("c1 = "+c1);
        System.out.println("c2 = "+c2);
        System.out.println("c1 + c2 = "+(c1.$plus(c2)));
        System.out.println("c1 - c2 = "+(c1.$minus(c2)));
        System.out.println("-c1 = "+(c1.unary_$minus()));
        System.out.println("c1.real = "+(c1.real()));
        System.out.println("c1.imaginary = "+(c1.imaginary()));
    }
}
