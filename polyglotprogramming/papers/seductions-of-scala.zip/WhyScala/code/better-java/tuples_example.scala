def tupleator(a: Any, b: Any, c: Any) = (a, b, c)

val tup = tupleator(1, "one", 1.1)
println(tup._1)    // => 1
println(tup._2)    // => "one"
println(tup._3)    // => 1.1

val (x, y, z) = tupleator(2, "two", 2.2)
println(x)         // => 2
println(y)         // => "two"
println(z)         // => 2.2

