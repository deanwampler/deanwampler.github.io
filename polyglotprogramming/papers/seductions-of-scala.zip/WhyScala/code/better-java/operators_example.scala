//START:definition
class Complex(val real: Double, val imaginary: Double)
{
  def +(that: Complex) = 
    new Complex(real+that.real, imaginary+that.imaginary)
  def -(that: Complex) = 
    new Complex(real-that.real, imaginary-that.imaginary)
  def unary_- = 
    new Complex(-real, imaginary)
  override def toString() = "("+real+", "+imaginary+")"
}
//END:definition

//START:examples
val c1 = new Complex(1.1, 1.1)
val c2 = new Complex(2.2, 2.2)
println("c1 + c2 = " + (c1 + c2))  // => (3.3, 3.3)
println("c1 - c2 = " + (c1 - c2))  // => (-1.1, -1.1)

var c3 = new Complex(3.3, 3.3) 
c3 += c1      // same as c3 = c3 + c1
println("c3 = "+ c3)               // => (4.4, 4.4)

println("-c1 = " + (-c1))          // => (-3.3, 3.3)
//END:examples
