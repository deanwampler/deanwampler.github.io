README.txt
Dean Wampler, dean@aspectprogramming.com

The code examples used in the presentation. 

There are actually some code examples that you won't find in the presentation, usually because they were used in earlier drafts, then replaced. I left them here just to provide the reader will more Scala to puzzle over ;)

In many cases, you can just run the Scala files with "scalac filename". In other cases, you have to compile first with "scalac" then either run "scala" with the .class file or perhaps the .class file is used by other "scripts". The shapes.scala and shapes-actor.scala files in the functions directory must be compiled, for example.

Send me email if you have questions or comments.
