//START:definitions
trait InputChannel[+T] {   // Covariant under inheritance
	def read(): T 
} 

trait OutputChannel[-T] {  // Contravariant under inheritance
	def write(t: T)
} 
//END:definitions

// The slides actual use examples2a & b.
//START:examples1
class C1 {
    override def toString() = "C1"
}
class C2 extends C1 {
    override def toString() = "C2"
}
class C3 extends C2 {
    override def toString() = "C3"
}

var inC1 = new InputChannel[C1] {
    def read() = new C1
}
var inC2 = new InputChannel[C2] {
    def read() = new C2
}
var inC3 = new InputChannel[C3] {
    def read() = new C3
}
var outC3 = new OutputChannel[C3] {
    def write(x: C3) = println(x)
}
var outC2 = new OutputChannel[C2] {
    def write(x: C2) = println(x)
}
var outC1 = new OutputChannel[C1] {
    def write(x: C1) = println(x)
}

def echo1[T](in: InputChannel[T], out: OutputChannel[T]) = {
    out.write(in.read())
}

echo1[C2](inC3, outC1) // => C3
//END:examples1

//START:examples2a
var inAny = new InputChannel[Any] {
    def read() = 1  // return type Any, but actually returns an Int
}
var outAny = new OutputChannel[Any] {
    def write(x: Any) = println("Any: "+x)
}
var inString = new InputChannel[String] {
    def read() = "Hello!"
}
var outString = new OutputChannel[String] {
    def write(x: String) = println("String: "+x)
}
//END:examples2a
//START:examples2b
def echo[T](in: InputChannel[T], out: OutputChannel[T]) = {
    out.write(in.read())
}
echo[Any](inAny, outAny)          // => Any: 1
echo[String](inString, outString) // => String: Hello!

echo[Any](inString, outAny)       // => Any: Hello!
echo[String](inString, outAny)    // => Any: Hello!
//END:examples2b
