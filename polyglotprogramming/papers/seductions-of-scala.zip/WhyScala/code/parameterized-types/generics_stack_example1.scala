class Stack[+A] {
  def push[B >: A](elem: B): Stack[B] = new Stack[B] {...}
  def top: A = error("no element on stack")
  def pop: Stack[A] = error("no element on stack")
  override def toString() = ""
}
