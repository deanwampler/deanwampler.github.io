class Stack[+A] {
  def push[B >: A](elem: B): Stack[B] = new Stack[B] {
    override def top: B = elem
    override def pop: Stack[B] = Stack.this  // original Stack
    override def toString() = 
		elem.toString() + ", " + Stack.this.toString()
  }
  def top: A = error("no element on stack")
  def pop: Stack[A] = error("no element on stack")
  override def toString() = ""
}
val s1 = new Stack[String]().push("hello");
val s2 = s1.push(5.6).push(7)
println("s1: "+s1)   // => s1: hello, 
println("s2: "+s2)   // => s2: 7, 5.6, hello, 
