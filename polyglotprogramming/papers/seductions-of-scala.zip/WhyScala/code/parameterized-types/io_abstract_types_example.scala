// The channel example rewritten using abstract types. 
// It could probably be cleaner...
//START:definitions
abstract trait Channel { 
    type T
} 

trait InputChannel extends Channel { 
    type I <: T    // I must be a subtype of T
	def read(): I
} 

trait OutputChannel extends Channel {
    type O >: T    // O must be a supertype of T
	def write(x: O)
} 
//END:definitions

//START:definitions2
class C1 {
    override def toString() = "C1"
}
class C2 extends C1 {
    override def toString() = "C2"
}
class C3 extends C2 {
    override def toString() = "C3"
}
//END:definitions2

//START:examples1
class InC3 extends InputChannel {
    type T = C2
    type I = C3
    def read() = new C3
}

class OutC1 extends OutputChannel {
    type T = C2
    type O = C1
    def write(x: C1) = println(x)
}

abstract class Echo1 {
    type IN  <: InputChannel  { type T = C2; type I = C3 }
    type OUT <: OutputChannel { type T = C2; type O = C1 }
    def echo1(in: IN, out: OUT) = {
        out.write(in.read())
    }
}

class MyEcho1 extends Echo1 {
    type IN = InC3
    type OUT = OutC1
}
(new MyEcho1).echo1(new InC3, new OutC1)  // => C3
//END:examples1

//START:examples2a
class InAny extends InputChannel {
    type T = Any
    type I = String
    def read() = "Any"
}
class OutAny extends OutputChannel {
    type T = Any
    type O = Any
    def write(x: Any) = println("Any: "+x)
}
class InString extends InputChannel {
    type T = String
    type I = String
    def read() = "String"
}
class OutString extends OutputChannel {
    type T = String
    type O = Any
    def write(x: Any) = println("String: "+x)
}
//END:examples2a

//START:examples2b
abstract class AnyEcho {
    type IN  <: InputChannel  { type T = Any; type I = String }
    type OUT <: OutputChannel { type T = Any; type O = Any }
    def echo(in: IN, out: OUT) = {
        out.write(in.read())
    }
}

abstract class StringEcho {
    type IN  <: InputChannel  { type T = String; type I = String }
    type OUT <: OutputChannel { type T = String; type O = Any }
    def echo(in: IN, out: OUT) = {
        out.write(in.read())
    }
}
//END:examples2b

//START:examples2c
class MyAnyEcho extends AnyEcho {
    type T1 = Any
    type IN = InAny
    type OUT = OutAny
}

class MyStringEcho extends StringEcho {
    type T1 = String
    type IN = InString
    type OUT = OutString
}
(new MyAnyEcho).echo(new InAny, new OutAny)          // => Any: Any
(new MyStringEcho).echo(new InString, new OutString) // => String: String
//END:examples2c
