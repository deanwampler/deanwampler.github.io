Introduction to Aquarium
Dean Wampler
dean@objectmentor.com
April 16, 2008

Exercises for "Aquarium_RubyAOP.pdf", available at http://aspectprogramming.com/papers and based
on my talk on Aquarium at the Chicago Ruby Users Group (Chirb), 10/1/2007 (It's been updated to
reflect recent API changes). 

Each exercise is in an "ex<n>" folder. There is a possible solution in each "ex<n>/solution" folder.

Exercise 1: Method tracing
Exercise 2: Advising method_missing
Exercise 3: Aspect-oriented design - safer pointcuts


Note: These exercises are based on the examples on the Aquarium website: http://aquarium.rubyforge.org/examples.html
