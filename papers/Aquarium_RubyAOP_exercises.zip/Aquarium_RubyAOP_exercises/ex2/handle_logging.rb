require 'rubygems'
require 'aquarium'

# Include the Aspects module. You could just use Aquarium::Aspects::Aspect.new...
include Aquarium::Aspects

# Note that normally the block arguments would be |join_point, object, *args|, 
# but we know that the args[0] will be the name symbol for the invoked method!
Aspect.new <...> do |join_point, object, method_symbol, *args|
  <...>
end

