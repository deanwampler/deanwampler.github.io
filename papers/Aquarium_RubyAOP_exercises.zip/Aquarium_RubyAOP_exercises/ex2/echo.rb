class Echo
  def method_missing sym, *args
    p "Echoing: #{sym.to_s}: #{args.join(" ")}"
  end
end

def tryit before_or_after
  p "#{before_or_after} advising Echo to handle logging differently:"
  echo = Echo.new
  echo.say "hello", "world!"
  echo.log "something", "interesting..."
  echo.shout "theater", "in", "a", "crowded", "firehouse!"
  p ""
end

tryit "Before"

p "Advice Echo:"
require 'handle_logging'

tryit "after"
