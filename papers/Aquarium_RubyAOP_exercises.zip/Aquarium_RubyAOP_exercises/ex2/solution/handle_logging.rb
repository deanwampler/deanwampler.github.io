require 'rubygems'
require 'aquarium'

# Include the Aspects module. You could just use Aquarium::Aspects::Aspect.new...
include Aquarium::Aspects

# Note that normally the block arguments would be |join_point *args|, but we know that
# the args[0] will be the name symbol for the invoked method!
Aspect.new :around, :calls_to => :method_missing, :in_type => Echo do |join_point, obj, sym, *args|
  if sym == :log 
    p "--- Sending to log: #{args.join(" ")}" 
  else
    join_point.proceed
  end
end

