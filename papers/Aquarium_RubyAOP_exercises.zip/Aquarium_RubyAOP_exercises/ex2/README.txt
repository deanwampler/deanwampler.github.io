
Exercise 2: Advising method_missing

A common problem that occurs when many toolkits are used is a "collision of the method_missings", where
each toolkit wants to control this method. One way to improve this situation is to use advice instead.

	echo.rb				Defines a class that uses method_missing to treat any method call
						as a request to "echo" the method name and the argument list.
	handle_logging.rb	Skeleton for an aspect that handles calls to pseudo-method :log differently.
	
You need to write an aspect that advices method_missing. You want it do something different if the
"pseudo-method" invoked is "log". (Just have it print out a different prefix...) Otherwise, Echo's method_missing should handle it.

You should use :around advice and invoke "jp.proceed" when the pseudo-method is not "log". The reason
for using around advice instead of :before advice is that the latter can't prevent the invocation of
the advised method (unless it throws an exception), whereas around advice lets you decide whether to
"proceed" or not.

To run your code, 

	ruby echo.rb

One solution is shown in the solution folder.


