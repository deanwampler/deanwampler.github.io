
Exercise 1: Method tracing

Install Aquarium if you haven't already done so:

	sudo gem install aquarium

Or, make sure you have updated to at least version 0.4.

This exercise uses the following files:

	myapp.rb			Defines two classes, then instantiates them and calls methods.
	trace_methods.rb	Skeleton of a "tracer aspect" to record entering and leaving methods.
	
You need to replace the <...> in trace_methods.rb with appropriate expressions to trace 
entering and leaving each method. What should be the type of advice? You could use :around
advice, but don't forget to call "jp.proceed" or else the original methods won't be invoked!

You could also use two separate aspects, one with :before and one with :after advice.

To run your code, 

	ruby myapp.rb

One solution is shown in the solution folder.


