require 'rubygems'
require 'aquarium'

# Include the Aspects module. You could just use Aquarium::Aspects::Aspect.new...
include Aquarium::Aspects

# Create an aspect that advises the "say" method in the classes explicitly.
# Aspect.new :around, :calls_to => :say, :in_types => [Class1, Class2] do |join_point, object, *args|
#   p ">> #{join_point.type_or_object}.#{join_point.method_name}"
#   join_point.proceed
#   p "<< #{join_point.type_or_object}.#{join_point.method_name}"
# end

# Create an aspect that advises the "say" method in the classes matching a regular expression.
Aspect.new :around, :calls_to => :say, :in_types => /Class[12]/ do |join_point, object, *args|
  p ">> #{join_point.type_or_object}.#{join_point.method_name}"
  result = join_point.proceed
  p "<< #{join_point.type_or_object}.#{join_point.method_name}"
  result   # Must return the result (although for "Class[12]" it doesn't really matter...)
end

# Here is another way to handle the general need to return a join_point's result.
# Note that the "ensure" clause doesn't change the result returned by the advice!
Aspect.new :around, :calls_to => :say, :in_types => /Class[12]/ do |join_point, object, *args|
  begin
    p ">> #{join_point.type_or_object}.#{join_point.method_name}"
    join_point.proceed
  ensure
    p "<< #{join_point.type_or_object}.#{join_point.method_name}"
  end
end
