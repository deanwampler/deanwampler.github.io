require 'rubygems'
require 'aquarium'

# Include the Aspects module. You could just use Aquarium::Aspects::Aspect.new...
include Aquarium::Aspects

Aspect.new <:which_advice_type>, :calls_to => :say, :in_types => [<...>] do |join_point, object, *args|
  <print output>
end
