
class Class1
  def say message
    p "Class1.say: #{message}"
  end
end

class Class2
  def say message
    p "Class2.say: #{message}"
  end
end

require 'trace_methods'

Class1.new.say "Hello World!"
p ""
Class2.new.say "Buon Giorno!"
