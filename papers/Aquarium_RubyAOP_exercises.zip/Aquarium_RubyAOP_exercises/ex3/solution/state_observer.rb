require 'rubygems'
require 'aquarium'

# Include the Aspects module. You could just use Aquarium::Aspects::Aspect.new...
include Aquarium::Aspects

# Observe state changes in the class, using the class-defined pointcut.

observer = Aspect.new :after, :pointcut => ClassWithStateAndBehavior::STATE_CHANGE do |jp, object, *args|
  p "State has changed. "
  p "  New state is #{object.state.inspect}"
  p "  Equivalent to *args: #{args.inspect}"
end  
