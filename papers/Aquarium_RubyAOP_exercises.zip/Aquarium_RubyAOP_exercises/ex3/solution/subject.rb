require 'rubygems'
require 'aquarium'

class ClassWithStateAndBehavior
  # include the "DSL" methods in this class.
  include Aquarium::DSL
  
  def initialize *args
    @state = args
    p "Initializing: #{args.inspect}"
  end
  
  attr_accessor :state

  # A functionally-equivalent version of the following would be 
  # STATE_CHANGE = pointcut :method => :state=
  STATE_CHANGE = pointcut :writing => :state
end

require 'state_observer'

object = ClassWithStateAndBehavior.new(:a1, :a2, :a3)
object.state = [:b1, :b2]
object.state = [:c1]
