Introduction to Aquarium
Chirb 10/1/07
Dean Wampler
dean@objectmentor.com

Exercise 3: Aspect-oriented design - safer pointcuts

One of the early design lessons that the AOP community learned is that pointcuts can be very fragile. 
For example, recall our first exercise:

	class Class1
	  def say message; ...; end
	end
	class Class2
	  def say message; ...; end
	end

and

	Aspect.new :around, :calls_to => :say, :in_types => /Class[12]/ ...

What if I rename either class or the method :say? Chances are, I'll forget to change the :types or
:method in this aspect. Even in the Java/AspectJ world, no tools properly handle this refactoring.

One of the better ideas that has emerged is for classes to be "aware" that they might get advised
by aspects and for those classes to take responsibility for defining a reasonable set of pointcuts
that potential aspects might use. This exercise demonstrates how that might work, effectively
implementing the observer pattern.

	subject.rb			Defines a class that undergoes state changes of interest to "observers".
	state_observer.rb	Skeleton for an aspect that prints state changes to the output.
	

Note that subject.rb has this include statement:

    include Aquarium::DSL

This includes several convenience methods in the defined class. Among other things, this let's
you write

	after :calls_to => :foo...

instead of

	Aspect.new :after, :calls_to => :foo...

In our case, we use the added :pointcut method to define a pointcut that your Observer will use
to watch for state changes.

You need to complete the aspect in "state_observer.rb" to watch for state changes and to write the
changed state to the output. Notice that the :pointcut => ClassWithStateAndBehavior::STATE_CHANGE
will never break as long as the maintainers of subject.rb update the pointcut appropriate, as 
needed. This is a form of "interface-based" programming, Ruby style. (Note that Java users might
also define pointcuts that match on annotations. An example of this is <shameless-plug>my 
Contract4J toolkit (http://contract4j.org)</shameless-plug>.)

To run your code, 

	ruby subject.rb

One solution is shown in the solution folder.


